package com.dicoding.mutiarahmatun.jetpack.moviefilm.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}