package com.dicoding.mutiarahmatun.jetpack.moviefilm.data.source.remote.vo

enum class StatusResponse {
    SUCCESS,
    ERROR
}