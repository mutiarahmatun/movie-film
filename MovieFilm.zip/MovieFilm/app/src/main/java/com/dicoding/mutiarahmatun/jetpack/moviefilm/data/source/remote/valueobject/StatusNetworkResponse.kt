package com.dicoding.mutiarahmatun.jetpack.moviefilm.data.source.remote.valueobject

enum class StatusNetworkResponse {
    SUCCESS,
    ERROR,
    EMPTY
}