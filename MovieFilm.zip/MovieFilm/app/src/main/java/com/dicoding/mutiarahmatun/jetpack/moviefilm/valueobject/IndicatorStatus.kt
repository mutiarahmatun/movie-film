package com.dicoding.mutiarahmatun.jetpack.moviefilm.valueobject

enum class IndicatorStatus {
    SUCCESS,
    ERROR,
    LOADING
}